

    Icons:
		Themify Icons: 		(https://themify.me/themify-icons)

	Other:
		JQuery: 			(https://www.jquery.com)
		Bootstrap: 			(https://www.getbootstrap.com)
		Bootstrap Affix: 	(http://getbootstrap.com/javascript/#affix)  
		Isotope: 			(https://isotope.metafizzy.co/) 
		Google Maps:		(https://maps.google.com)
